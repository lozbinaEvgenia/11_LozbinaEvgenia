enum class ColorType {
    RED {
        override fun ColorName() = "Красный";
        override val lightness = "Светло"
        override fun Meaning() : String = "Красный - цвет жизни, солнца, огня"
        override val warmless: String = "Нейтральный"
    },
    BLUE {
        override fun ColorName() = "Голубой";
        override val lightness = "Тёмно"
        override fun Meaning(): String = "Голубой цвет привносит ощущение мира и бесконечности, расслабляет человека"
        override val warmless : String = "Холодный"
    },
    GREEN {
        override fun ColorName() = "Зелёный";
        override val lightness = "Светло"
        override fun Meaning(): String = "Зелёный - самый распространённый цвет в европейской природе"
        override val warmless : String = "Нейтральный"
    };

    abstract fun ColorName(): String
    abstract val lightness: String
    fun NameWithLightness(): String = "$lightness - ${this.ColorName()}"
    abstract fun Meaning(): String
    abstract val warmless : String
    fun WarmlessWithNameWithLightness(): String = "$warmless ${this.NameWithLightness()}"
}