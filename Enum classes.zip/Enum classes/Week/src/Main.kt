//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val weekMonday = Weekdays.Monday
    println(weekMonday.DayName())
    println("Номер недели: " + weekMonday.IndexDay())
    println(weekMonday.Planets())
    println(weekMonday.Taro())

    val weekTuesday = Weekdays.Tuesday
    println(weekTuesday.DayName())
    println("Номер недели: " + weekTuesday.IndexDay())
    println(weekTuesday.Planets())
    println(weekTuesday.Taro())

    val weekWednesday = Weekdays.Wednesday
    println(weekWednesday.DayName())
    println("Номер недели: " + weekWednesday.IndexDay())
    println(weekWednesday.Planets())
    println(weekWednesday.Taro())

    val weekThursday = Weekdays.Thursday
    println(weekThursday.DayName())
    println("Номер недели: " + weekThursday.IndexDay())
    println(weekThursday.Planets())
    println(weekThursday.Taro())

    val weekFriday = Weekdays.Friday
    println(weekFriday.DayName())
    println("Номер недели: " + weekFriday.IndexDay())
    println(weekFriday.Planets())
    println(weekFriday.Taro())

    val weekSaturday = Weekdays.Saturday
    println(weekSaturday.DayName())
    println("Номер недели: " + weekSaturday.IndexDay())
    println(weekSaturday.Planets())
    println(weekSaturday.Taro())

    val weekSunday = Weekdays.Sunday
    println(weekSunday.DayName())
    println("Номер недели: " + weekSunday.IndexDay())
    println(weekSunday.Planets())
    println(weekSunday.Taro())
}