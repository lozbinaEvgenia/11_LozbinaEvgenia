enum class Weekdays {
    Monday {
        override fun DayName() = "Понедельник"
        override fun IndexDay() = 2
        override fun Planets() = "Покровитель дня - Луна"
        override fun Taro() = "Планета дня - Луна. Она обостряет чувства человека, его восприимчивость к событиям тонкого мира"
    },
    Tuesday {
        override fun DayName() = "Вторник"
        override fun IndexDay() = 3
        override fun Planets() = "Покровитель дня - Марс"
        override fun Taro() = "Вторнику соответствует воинственный Марс. Упрямство, напор, агрессия, борьба, ссоры и конфликты - верные спутники Марса, ярко проявляющие себя в этот день недели."
    },
    Wednesday {
        override fun DayName() = "Среда"
        override fun IndexDay() = 4
        override fun Planets() = "Покровитель дня - Меркурий"
        override fun Taro() = "Планета среды - Меркурий, отвечающий за торговлю, за путешествия, за контакты и связи с общественностью."
    },
    Thursday {
        override fun DayName() = "Четверг"
        override fun IndexDay() = 5
        override fun Planets() = "Покровитель дня - Юпитер"
        override fun Taro() = "Возможно, Четверг - самый благоприятный день недели, поскольку Юпитер - планета щедрая, добрая, ориентированная на успешность и удачу."
    },
    Friday {
        override fun DayName() = "Пятница"
        override fun IndexDay() = 6
        override fun Planets() = "Покровитель дня - Венера"
        override fun Taro() = "Пятница связана с любовной сферой, также она заведует красотой и эстетикой, искусством, чувственностью, плодородием и деньгами"
    },
    Saturday {
        override fun DayName() = "Суббота"
        override fun IndexDay() = 7
        override fun Planets() = "Покровитель дня - Сатурн"
        override fun Taro() = "Сатурн склонен к размышлениям, философии, является олицетворением фатальности."
    },
    Sunday {
        override fun DayName() = "Воскресенье"
        override fun IndexDay() = 1
        override fun Planets() = "Покровитель дня - Солнце"
        override fun Taro() = "Солнце несёт добро, стремится к лидерству, поощряет работу над собой."
    };

        abstract fun DayName(): String
        abstract fun IndexDay(): Int
        abstract fun Planets(): String
        abstract fun Taro(): String
}